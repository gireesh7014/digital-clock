package com.example.worldclock;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private TextView digitalClock;
    private TextView timeZone1, timeZone2, timeZone3, timeZone4;
    private final Handler handler = new Handler();
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link the digital clock TextView
        digitalClock = findViewById(R.id.digitalClock);

        // Link additional TextViews for time zones
        timeZone1 = findViewById(R.id.timeZone1);
        timeZone2 = findViewById(R.id.timeZone2);
        timeZone3 = findViewById(R.id.timeZone3);
        timeZone4 = findViewById(R.id.timeZone4);

        // Start updating the digital clock and time zones
        updateClock();
    }

    private void updateClock() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Update the local time
                String currentTime = timeFormat.format(new Date());
                digitalClock.setText(currentTime);

                // Update the time for different time zones
                updateTimeZone(timeZone1, "UTC");
                updateTimeZone(timeZone2, "America/New_York");
                updateTimeZone(timeZone3, "Asia/Tokyo");
                updateTimeZone(timeZone4, "Australia/Sydney");

                // Recursive call for continuous updates
                handler.postDelayed(this, 1000);
            }
        }, 0);
    }

    private void updateTimeZone(TextView textView, String timeZoneId) {
        // Set the time zone
        SimpleDateFormat timeZoneFormat = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
        timeZoneFormat.setTimeZone(TimeZone.getTimeZone(timeZoneId));

        // Get the current time in the specified time zone
        String timeZoneTime = timeZoneFormat.format(new Date());
        textView.setText(timeZoneId + ": " + timeZoneTime);
    }
}
